import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import javax.sound.midi.*; 
import interfascia.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class SongCreator extends PApplet {




GUIController c;
IFTextField inName,inArtist,inBPM;
IFLabel lName,lArtist,lBPM,lPath;
IFButton b1,b2;

String songName="";
String artist="";
String songData="";
String bpm="";

String midiPath="";
  
PrintWriter output;

int margin=75;
int spacing=35;

IFLookAndFeel skin;

String errorMessage="";

PImage img;

public void setup() {
  
  
  surface.setResizable(false);
  
  img=loadImage("text.png");
  
  skin = new IFLookAndFeel(this, IFLookAndFeel.DEFAULT);
  skin.textColor = color(0);
  
  surface.setTitle("MusicWave Song Generator");
  
  output = createWriter("data.txt");
  
  c = new GUIController(this);
  
  inName = new IFTextField("Text Field", margin, margin, 150);
  
  inArtist = new IFTextField("Text Field", margin, margin+spacing, 150);
  
  inBPM = new IFTextField("Text Field", margin, margin+(spacing*2), 150);
  
  b1 = new IFButton ("Select a MIDI", 5, margin+(spacing*3), 150, 17);
  lPath = new IFLabel("", 1000, margin+5+(spacing*4-(spacing/2)));
  
  b2 = new IFButton ("Create Song!", width/2-(150/2), margin+(spacing*5), 150, 17);
  
  c.setLookAndFeel(skin);
  
  c.add(inName);
  
  c.add(inArtist);
  
  c.add(inBPM);
  
  c.add (b1);
  c.add(lPath);
  
  c.add (b2);
  
  
  
  inName.addActionListener(this);
  inArtist.addActionListener(this);
  inBPM.addActionListener(this);
  b1.addActionListener(this);
  b2.addActionListener(this);
  lPath.addActionListener(this);
  
}

public void actionPerformed(GUIEvent e) {
  //if (e.getMessage().equals("Completed")) {
    if(e.getSource() == inName){
      songName=inName.getValue();
    } else if(e.getSource() == inArtist){
      artist=inArtist.getValue();
    } else if(e.getSource() == inBPM){
      bpm=inBPM.getValue();
    }
  //}
  
  if(e.getSource() == b1){
    selectInput("Select a file to process:", "fileSelected");
  } else if(e.getSource() == b2){
    
    if(songName.equals("") || artist.equals("") || bpm.equals("") || songData.equals("")){
      print("could not create song");
      errorMessage= "Error: Could not create song. Missing field or MIDI?";
      return;
    }
    String textFile = "";
    
    textFile+=songName+"\n";
    textFile+=artist+"\n";
    textFile+=bpm+"\n";
    textFile+="custom"+"\n";
    textFile+="~"+"\n";
    textFile+=songData;
    
    output.print(textFile);
    output.flush();
    output.close();
    exit();
    
  }
  
}

public void draw(){
  background(20);
  
  image(img,width/2-((116*(5/2))/2),10,116*(5/2),16*(5/2));
  
  fill(0,84,255);
  text("v 1.0",width/2+((116*(5/2))/2)-25,53);
  
  fill(255);
  text("Song Generator",width/2-((116*(5/2))/2),53);
  
  text("Song Title",5,margin+15);
  text("Artist Name",5,margin+spacing+15);
  text("BPM",5,margin+(spacing*2)+15);
  
  text(songName,5+230,margin+15);
  text(artist,5+230,margin+spacing+15);
  text(bpm,5+230,margin+(spacing*2)+15);
  
  text(midiPath,5, margin+15+(spacing*4-(spacing/2)));
  
  fill(255,0,0);
  text(errorMessage,10,height-10);
}

public void fileSelected(File selection) {
  if (selection == null) {
    println("Window was closed or the user hit cancel.");
  } else {
    midiPath = selection.getAbsolutePath();
    lPath.setLabel(midiPath);
    GenerateTextFromMidi();
  }
}
  
public void GenerateTextFromMidi(){
  String path = midiPath;
  File midiFile = new File(path);
  try {
    Sequence seq = MidiSystem.getSequence(midiFile);
    Track[] tracks = seq.getTracks();

    // how many tracks are there
    //println("number of tracks: "+ tracks.length);

    // parse first track
    //println("events of 1st track:");
    
    int largestTrack = 0;
    int largestTrackSize=0;
    
    for (int i = 0; i < tracks.length; i++){
        if(tracks[i].size()>largestTrackSize){
          largestTrack=i;
          largestTrackSize=tracks[i].size();  
      }
    }
    
    Track myTrack = tracks[largestTrack];

    for (int j =0; j< myTrack.size(); j++) {
      // get midi-message for every event
      if (myTrack.get(j).getMessage() instanceof ShortMessage) {
        ShortMessage m =  (ShortMessage) myTrack.get(j).getMessage();
        
        // log note-on or note-off events
        int cmd = m.getCommand();
        if (cmd == ShortMessage.NOTE_ON) {

          songData+= myTrack.get(j).getTick()+" "+ m.getData1()+"\n";
          //print( (cmd==ShortMessage.NOTE_ON ? "NOTE_ON" : "NOTE_OFF") + "; ");
          //print("channel: " + m.getChannel() + "; ");
        }
      }
    }
    errorMessage="";
    print(songData);
}

  catch(Exception e) {
    e.printStackTrace();
    errorMessage="Error: Issue processing MIDI";
    
    //exit();
  }
}
  public void settings() {  size(400,300); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "SongCreator" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
